<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
      Sistem Informasi AudioTest Pro
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2023 <a href="#">Sistem Informasi AudioTest Pro</a>.</strong> All rights reserved.
  </footer>
