<?php 
return [
    'title' => 'Data Master',
    'h1' => 'DATA MASTER',
    'pegawai' => 'Data Pegawai',
    'lihat' => 'Lihat',
    'posisi' => 'Data Posisi Pegawai',
    'ruang' => 'Data Ruang Kerja',
]; 