<?php 
return [
    'keterangan' => 'Keterangan: (*) Rata-rata',
    'ruang' => 'Ruang Kerja',
    'bising' => 'Tingkat Kebisingan',
    'hasil' => 'Hasil Audiometri',
    'usia' => 'Usia Pegawai',
    'rekomendasi' => 'Rekomendasi',
    'menuAudiometri' => 'Hasil Audiometri',
    'menuData' => 'Data Master',
    'menuRekomendasi' => 'Hasil Rekomendasi',
    'lihat' => 'Lihat',
    'tahun' => 'Tahun'
]; 