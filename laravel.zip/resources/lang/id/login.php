<?php 
return [
    'masuk' => 'MASUK',
    'email' => 'Alamat Email',
    'password' => 'Kata Sandi',
    'button' => 'MASUK'
]; 