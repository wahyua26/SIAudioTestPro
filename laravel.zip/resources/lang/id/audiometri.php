<?php 
return [
    'title' => 'Data Hasil Audiometri',
    'h1' => 'DATA HASIL AUDIOMETRI',
    'nama' => 'Nama Lengkap',
    'tanggal' => 'Tanggal',
    'waktu' => 'Waktu',
    'hasil' => 'Hasil',
    'aksi' => 'Aksi',
]; 