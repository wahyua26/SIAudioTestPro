<?php 
return [
    'title' => 'Detail Hasil Audiometri',
    'h1' => 'DETAIL HASIL AUDIOMETRI',
    'kiri' => 'Telinga Kiri',
    'hasil' => 'Hasil Tes',
    'kanan' => 'Telinga Kanan',
    'seluruh' => 'Hasil Keseluruhan',
    'cetak' => 'Cetak Detail',
]; 