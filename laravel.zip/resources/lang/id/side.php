<?php 
return [
    'menuAudiometri' => 'Hasil Audiometri',
    'menuData' => 'Data Master',
    'menuRekomendasi' => 'Hasil Rekomendasi',
    'dataPegawai' => 'Data Pegawai',
    'dataPosisi' => 'Data Posisi Pegawai',
    'dataRuangan' => 'Data Ruang Kerja',
    'keluar' => 'Keluar'
]; 