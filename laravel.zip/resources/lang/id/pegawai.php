<?php 
return [
    'title' => 'Data Pegawai',
    'h1' => 'DATA PEGAWAI',
    'tambah' => 'Tambah Pegawai',
    'nama' => 'Nama Lengkap',
    'email' => 'Email',
    'tanggal' => 'Tanggal Lahir',
    'jabatan' => 'Posisi Pegawai',
    'ruang' => 'Ruang Kerja',
    'status' => 'Status',
    'aksi' => 'Aksi',
    'ubah' => 'Ubah',
    'hapus' => 'Hapus',
]; 