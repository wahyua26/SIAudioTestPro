<?php 
return [
    'title' => 'Audiometry Result',
    'h1' => 'AUDIOMETRY RESULT',
    'nama' => 'Full Name',
    'tanggal' => 'Date',
    'waktu' => 'Time',
    'hasil' => 'Result',
    'aksi' => 'Action',
]; 