<?php 
return [
    'title' => 'Employees Data',
    'h1' => 'EMPLOYEES DATA',
    'tambah' => 'Add Employee',
    'nama' => 'Full Name',
    'email' => 'Email',
    'tanggal' => 'Birth Date',
    'jabatan' => 'Employee Position',
    'ruang' => 'Workspaces',
    'status' => 'Status',
    'aksi' => 'Action',
    'ubah' => 'Edit',
    'hapus' => 'Delete',
]; 