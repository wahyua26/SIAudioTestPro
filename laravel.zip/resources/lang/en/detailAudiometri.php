<?php 
return [
    'title' => 'Audiometry Result Detail',
    'h1' => 'AUDIOMETRY RESULT DETAIL',
    'kiri' => 'Left Ear',
    'hasil' => 'Test Result',
    'kanan' => 'Right Ear',
    'seluruh' => 'Overall Result',
    'cetak' => 'Print Detail',
]; 