<?php 
return [
    'menuAudiometri' => 'Audiometry Result',
    'menuData' => 'Master Data',
    'menuRekomendasi' => 'Recommendation Result',
    'dataPegawai' => 'Employees Data',
    'dataPosisi' => 'Employees Position Data',
    'dataRuangan' => 'Workspaces Data',
    'keluar' => 'Logout'
]; 