<?php 
return [
    'masuk' => 'LOGIN',
    'email' => 'Email',
    'password' => 'Password',
    'button' => 'LOGIN'
]; 