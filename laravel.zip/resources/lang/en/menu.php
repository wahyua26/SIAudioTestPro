<?php 
return [
    'title' => 'Master Data',
    'h1' => 'MASTER DATA',
    'pegawai' => 'Employees Data',
    'lihat' => 'More Info',
    'posisi' => 'Employees Position Data',
    'ruang' => 'Workspaces Data',
]; 