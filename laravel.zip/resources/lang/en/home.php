<?php 
return [
    'keterangan' => 'Explanation: (*) Average',
    'ruang' => 'Workspace',
    'bising' => 'Noise Level',
    'hasil' => 'Audiometry Result',
    'usia' => 'Employee Age',
    'rekomendasi' => 'Recommendation',
    'menuAudiometri' => 'Audiometry Result',
    'menuData' => 'Master Data',
    'menuRekomendasi' => 'Recommendation Result',
    'lihat' => 'More Info',
    'tahun' => 'Years'
]; 