<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use GuzzleHttp\Client;

class LoginController extends Controller
{
    public function index(){
        return view('login');
    }

    public function authenticate(Request $request){
        $credentials = $request->validate([
            'email' => 'required|email',
            'password' => 'required'
        ]);
        //dd($request);

        if (Auth::attempt($credentials)) {
            $request->session()->regenerate();
            $user = User::where('users.email', $request->email)->first();
            //dd($request->email, $user->status);
            if($user->status == 'admin'){
                return redirect()->intended('/home')->with('success','Anda Berhasil Masuk!');
            }
            else{
                return redirect()->intended('/homePegawai/'.$user->id)->with('success','Anda Berhasil Masuk!');
            }
        }
        return back()->with('fail', 'Email atau Password anda Salah!');   

        // $http = new Client();
        // $api = 'https://audiotestpro.higitech.id/restapi/periksa_login';
        // $response = $http->post($api, [
        //     'headers' => [
        //         'Content-Type' => 'application/x-www-form-urlencoded',
        //     ],
        //     'form_params' => [
        //         'api-audiotest' => '3b96481852b94346d4e30c7f767ddc76c03db0eb;com.mobile.presensidemo',
        //         'email' => $request->email,
        //         'password' => $request->password
        //     ],
        //     'http_errors' => false
        // ]);
        // $api_result = json_decode((string)$response->getBody(), true);
        // if ($api_result['sukses'] == '1') {
        //     return 'sukses login';
        // }
    }

    public function logout(){
        Auth::logout();
        return redirect('/')->with('success', 'Anda Berhasil Keluar!');
    }

}
