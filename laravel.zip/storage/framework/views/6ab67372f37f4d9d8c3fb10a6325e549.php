 
<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html>
<head>
    <title><?php echo app('translator')->get('menu.title'); ?></title>
    <?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="hold-transition sidebar-mini">
            <?php if(Session::has('success')): ?>
              <script type="text/javascript">
                  swal({
                      title:'Success!',
                      text:"<?php echo e(Session::get('success')); ?>",
                      timer:5000,
                      type:'success',
                      icon: 'success'
                  }).then((value) => {
                    //location.reload();
                  }).catch(swal.noop);
              </script>
            <?php endif; ?>
            <?php if(Session::has('error')): ?>
              <script type="text/javascript">
                  swal({
                      title:'Error!',
                      text:"<?php echo e(Session::get('error')); ?>",
                      timer:5000,
                      type:'error',
                      icon: 'error'
                  }).then((value) => {
                    //location.reload();
                  }).catch(swal.noop);
              </script>
            <?php endif; ?>
            <?php if(isset($errors) && $errors->any()): ?>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <script type="text/javascript">
                  swal({
                      title:'Error!',
                      text:"<?php echo e($error); ?>",
                      timer:5000,
                      type:'error',
                      icon: 'error'
                  }).then((value) => {
                    //location.reload();
                  }).catch(swal.noop);
                </script>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
<div class="wrapper ">

  <!-- Navbar -->
  <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php echo $__env->make('layouts.side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm">
            <h1 class="m-0 font-weight-bold"><?php echo app('translator')->get('menu.h1'); ?></h1>
          </div><!-- /.col -->
          <div class="col-sm">
            
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="row">
        <div class="col"></div>
        <div class="col-lg-3">
          <div class="small-box text-white">
            <div class="inner">
              <h3><?php echo e($user); ?></h3>
              <p><?php echo app('translator')->get('menu.pegawai'); ?></p>
            </div>
            <div class="icon">
              <i class="nav-icon fas fa-users"></i>
            </div>
            <a href="<?php echo e(route('pegawai')); ?>" class="small-box-footer text-white"><?php echo app('translator')->get('menu.lihat'); ?> <i class="fas fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <div class="col-lg-3">
          <div class="small-box text-white">
            <div class="inner">
              <h3><?php echo e($jabatan); ?></h3>
              <p><?php echo app('translator')->get('menu.posisi'); ?></p>
            </div>
            <div class="icon">
              <i class="nav-icon fas fa-user-friends"></i>
            </div>
            <a href="<?php echo e(route('jabatan')); ?>" class="small-box-footer text-white"><?php echo app('translator')->get('menu.lihat'); ?> <i class="fas fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <div class="col-lg-3">
          <div class="small-box text-white">
            <div class="inner">
              <h3><?php echo e($ruangan); ?></h3>
              <p><?php echo app('translator')->get('menu.ruang'); ?></p>
            </div>
            <div class="icon">
              <i class="nav-icon fas fa-building"></i>
            </div>
            <a href="<?php echo e(route('ruang')); ?>" class="small-box-footer text-white"><?php echo app('translator')->get('menu.lihat'); ?> <i class="fas fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <div class="col"></div>
      </div>
    </div>
      
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Main Footer -->
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
<!-- ./wrapper -->

</div>
<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH D:\Kuliah\TA\siaudiotestpro\resources\views/master/menu.blade.php ENDPATH**/ ?>