<aside class="main-sidebar sidebar-light-primary elevation-4 bg-blue">
    <!-- Brand Logo -->
    <?php if(auth()->user()->status == 'admin'): ?>
    <a href="<?php echo e(route('home')); ?>" class="brand-link">
      <img src="<?php echo e(asset('AdminLTE/dist/img/logo7.png')); ?>" alt="SIATP Logo" class="brand-image" style="opacity: 1">
      <span>
        SIATP
      </span>
    </a>
    <?php endif; ?>
    <?php if(auth()->user()->status == 'pegawai'): ?>
    <a href="/homePegawai/<?php echo e(auth()->user()->id); ?>" class="brand-link">
      <img src="<?php echo e(asset('AdminLTE/dist/img/logo7.png')); ?>" alt="SIATP Logo" class="brand-image" style="opacity: 1">
      <span>
        SIATP
      </span>
    </a>
    <?php endif; ?>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="<?php echo e(asset('storage/images/' . auth()->user()->foto)); ?>"  class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="/detail-akun/<?php echo e(auth()->user()->id); ?>" class="d-block"><?php echo e(auth()->user()->name); ?></a>
        </div>
      </div>

      <!-- SidebarSearch Form -->
      

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          
          <?php if(auth()->user()->status == 'pegawai'): ?>
          <li class="nav-item">
            <a href="/audiometri-pegawai/<?php echo e(auth()->user()->id); ?>" class="nav-link">
              <i class="nav-icon fas fa-file-medical "></i>
              <p class="text-dark"><?php echo app('translator')->get('side.menuAudiometri'); ?></p>
            </a>
          </li>
          <?php endif; ?>
          <?php if(auth()->user()->status == 'admin'): ?>
          <li class="nav-item">
            <a href="<?php echo e(route('audiometri')); ?>" class="nav-link">
              <i class="nav-icon fas fa-file-medical "></i>
              <p class="text-dark"><?php echo app('translator')->get('side.menuAudiometri'); ?></p>
            </a>
          </li>
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-table"></i>
              <p>
                <?php echo app('translator')->get('side.menuData'); ?>
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('pegawai')); ?>" class="nav-link">
                  <i class="fas fa-users"></i>
                  <p><?php echo app('translator')->get('side.dataPegawai'); ?></p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('jabatan')); ?>" class="nav-link">
                  <i class="fas fa-user-friends"></i>
                  <p><?php echo app('translator')->get('side.dataPosisi'); ?></p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('ruang')); ?>" class="nav-link">
                  <i class="fas fa-building"></i>
                  <p><?php echo app('translator')->get('side.dataRuangan'); ?></p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item">
            <a href="<?php echo e(route('rekomendasi')); ?>" class="nav-link">
              <i class="nav-icon fas fa-clipboard "></i>
              <p class="text-dark"><?php echo app('translator')->get('side.menuRekomendasi'); ?></p>
            </a>
          </li>
          <br>
          <?php endif; ?>
        <li class="nav-item">
          <a href="<?php echo e(route('logout')); ?>" class="nav-link">
            <i class="fas fa-sign-out-alt"></i>
            <p><?php echo app('translator')->get('side.keluar'); ?></p>
          </a>
        </li>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside><?php /**PATH D:\Kuliah\TA\siaudiotestpro\resources\views/layouts/side.blade.php ENDPATH**/ ?>