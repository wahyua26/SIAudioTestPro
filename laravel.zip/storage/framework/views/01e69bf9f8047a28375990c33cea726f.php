 
<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html>
<head>
    <title><?php echo app('translator')->get('audiometri.title'); ?></title>
    <?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
      th {
        text-align: center;
      }
    </style>
</head>
<body class="hold-transition sidebar-mini">
            <?php if(Session::has('success')): ?>
              <script type="text/javascript">
                  swal({
                      title:'Success!',
                      text:"<?php echo e(Session::get('success')); ?>",
                      timer:5000,
                      type:'success',
                      icon: 'success'
                  }).then((value) => {
                    //location.reload();
                  }).catch(swal.noop);
              </script>
            <?php endif; ?>
            <?php if(Session::has('error')): ?>
              <script type="text/javascript">
                  swal({
                      title:'Error!',
                      text:"<?php echo e(Session::get('error')); ?>",
                      timer:5000,
                      type:'error',
                      icon: 'error'
                  }).then((value) => {
                    //location.reload();
                  }).catch(swal.noop);
              </script>
            <?php endif; ?>
            <?php if(isset($errors) && $errors->any()): ?>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <script type="text/javascript">
                  swal({
                      title:'Error!',
                      text:"<?php echo e($error); ?>",
                      timer:5000,
                      type:'error',
                      icon: 'error'
                  }).then((value) => {
                    //location.reload();
                  }).catch(swal.noop);
                </script>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
<div class="wrapper ">

  <!-- Navbar -->
  <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  
  <aside class="main-sidebar sidebar-light-primary elevation-4 bg-blue">
    <!-- Brand Logo -->
    <?php if(auth()->user()->status == 'admin'): ?>
    <a href="<?php echo e(route('home')); ?>" class="brand-link">
      <img src="<?php echo e(asset('AdminLTE/dist/img/logo7.png')); ?>" alt="SIATP Logo" class="brand-image" style="opacity: 1">
      <span>
        SIATP
      </span>
    </a>
    <?php endif; ?>
    <?php if(auth()->user()->status == 'pegawai'): ?>
    <a href="/homePegawai/<?php echo e(auth()->user()->id); ?>" class="brand-link">
      <img src="<?php echo e(asset('AdminLTE/dist/img/logo7.png')); ?>" alt="SIATP Logo" class="brand-image" style="opacity: 1">
      <span>
        SIATP
      </span>
    </a>
    <?php endif; ?>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="<?php echo e(asset('storage/images/' . auth()->user()->foto)); ?>"  class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="/detail-akun/<?php echo e(auth()->user()->id); ?>" class="d-block"><?php echo e(auth()->user()->name); ?></a>
        </div>
      </div>

      <!-- SidebarSearch Form -->
      

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          
          <?php if(auth()->user()->status == 'pegawai'): ?>
          <li class="nav-item">
            <a href="/audiometri-pegawai/<?php echo e(auth()->user()->id); ?>" class="nav-link">
              <i class="nav-icon fas fa-file-medical "></i>
              <p class="text-dark"><?php echo app('translator')->get('side.menuAudiometri'); ?></p>
            </a>
          </li>
          <?php endif; ?>
          <?php if(auth()->user()->status == 'admin'): ?>
          <li class="nav-item">
            <a href="<?php echo e(route('audiometri')); ?>" class="nav-link active">
              <i class="nav-icon fas fa-file-medical "></i>
              <p class="text-dark"><?php echo app('translator')->get('side.menuAudiometri'); ?></p>
            </a>
          </li>
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-table"></i>
              <p>
                <?php echo app('translator')->get('side.menuData'); ?>
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('pegawai')); ?>" class="nav-link">
                  <i class="fas fa-users"></i>
                  <p><?php echo app('translator')->get('side.dataPegawai'); ?></p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('jabatan')); ?>" class="nav-link">
                  <i class="fas fa-user-friends"></i>
                  <p><?php echo app('translator')->get('side.dataPosisi'); ?></p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('ruang')); ?>" class="nav-link">
                  <i class="fas fa-building"></i>
                  <p><?php echo app('translator')->get('side.dataRuangan'); ?></p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item">
            <a href="<?php echo e(route('rekomendasi')); ?>" class="nav-link">
              <i class="nav-icon fas fa-clipboard "></i>
              <p class="text-dark"><?php echo app('translator')->get('side.menuRekomendasi'); ?></p>
            </a>
          </li>
          <br>
          <?php endif; ?>
        <li class="nav-item">
          <a href="<?php echo e(route('logout')); ?>" class="nav-link">
            <i class="fas fa-sign-out-alt"></i>
            <p><?php echo app('translator')->get('side.keluar'); ?></p>
          </a>
        </li>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm">
            <h1 class="m-0 font-weight-bold"><?php echo app('translator')->get('audiometri.h1'); ?></h1>
          </div><!-- /.col -->
          <div class="col-sm">
            
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="row">
        <div class="col">
          <table class="table table-striped projects text-center">
            <tr>
                <th><?php echo app('translator')->get('audiometri.nama'); ?></th>
                <th><?php echo app('translator')->get('audiometri.tanggal'); ?></th>
                <th><?php echo app('translator')->get('audiometri.waktu'); ?></th>
                <th><?php echo app('translator')->get('audiometri.hasil'); ?></th>
                <th><?php echo app('translator')->get('audiometri.aksi'); ?></th>
            </tr> 
            <?php $__currentLoopData = $hasil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e($item->tanggal); ?></td>
                <td><?php echo e($item->waktu); ?></td>
                <td><?php echo e($item->keterangan); ?></div></td>
                <td class="project-actions text-center">
                  <a href="/detail-audiometri/<?php echo e($item->id); ?>" class="btn btn-info btn-sm">
                    <i class="fas fa-info-circle"></i> Detail
                  </a>
              </td>
            </tr> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </table>
        </div>
      </div>
    </div>
      
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Main Footer -->
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
<!-- ./wrapper -->

</div>
<!-- REQUIRED SCRIPTS -->
<!-- jQuery -->
<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH D:\Kuliah\TA\siaudiotestpro\resources\views/audiometri/index.blade.php ENDPATH**/ ?>