<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo e(GoogleTranslate::trans('Ubah Detail Ruang Kerja', app()->getLocale())); ?></title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(asset('AdminLTE/plugins/fontawesome-free/css/all.min.css')); ?>">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="<?php echo e(asset('AdminLTE/plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(asset('AdminLTE/dist/css/adminlte.min.css')); ?>">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>
  <style>
    .divider:after,
    .divider:before {
      content: "";
      flex: 1;
      height: 1px;
      background: #eee;
    }
    .h-custom {
      height: calc(100% - 73px);
    }
    @media (max-width: 450px) {
      .h-custom {
      height: 100%;
    }}
    body{color: #000;overflow-x: hidden;height: 100%;background-image: url("https://i.imgur.com/GMmCQHC.png");background-repeat: no-repeat;background-size: 100% 100%}.card{padding: 30px 40px;margin-top: 60px;margin-bottom: 60px;border: none !important;box-shadow: 0 6px 12px 0 rgba(0,0,0,0.2)}.blue-text{color: #00BCD4}.form-control-label{margin-bottom: 0}input, textarea, button{padding: 8px 15px;border-radius: 5px !important;margin: 5px 0px;box-sizing: border-box;border: 1px solid #ccc;font-size: 18px !important;font-weight: 300}input:focus, textarea:focus{-moz-box-shadow: none !important;-webkit-box-shadow: none !important;box-shadow: none !important;border: 1px solid #00BCD4;outline-width: 0;font-weight: 400}.btn-block{text-transform: uppercase;font-size: 15px !important;font-weight: 400;height: 43px;cursor: pointer}.btn-block:hover{color: #fff !important}button:focus{-moz-box-shadow: none !important;-webkit-box-shadow: none !important;box-shadow: none !important;outline-width: 0}
  </style>
</head>
<body>
  <?php if(Session::has('success')): ?>
      <script type="text/javascript">
        swal({
            title:'Success!',
            text:"<?php echo e(Session::get('success')); ?>",
            timer:5000,
            type:'success',
            icon: 'success'
        }).then((value) => {
          //location.reload();
        }).catch(swal.noop);
    </script>
    <?php endif; ?>

    <?php if(Session::has('fail')): ?>
    <script type="text/javascript">
        swal({
            title:'Oops!',
            text:"<?php echo e(Session::get('fail')); ?>",
            type:'error',
            timer:5000,
            icon: 'error'
        }).then((value) => {
          //location.reload();
        }).catch(swal.noop);
    </script>
    <?php endif; ?>

    <section class="vh-100">
      <div class="container-fluid h-custom">
        <div class="row d-flex justify-content-center align-items-center h-100">
          <div class="col-md-9 col-lg-6 col-xl-5">
            <img class="img-circle elevation-5" src="<?php echo e(asset('AdminLTE/dist/img/Picture1.png')); ?>"
              class="img-fluid" alt="Sample image">
          </div>
          <div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1">
            <div class="card">
              <h5 class="text-center mb-4 font-weight-bold"><?php echo e(GoogleTranslate::trans('UBAH DETAIL RUANG KERJA', app()->getLocale())); ?></h5>
              <?php if($errors->any()): ?>
                  <div class="alert alert-danger">
                      <ul>
                          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li><?php echo e($error); ?></li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </ul>
                  </div>
                <?php endif; ?>
              <form class="form-card" action="/update-ruang" method="post">
                  <?php echo csrf_field(); ?>
                  <div class="form-group col flex-column d-flex"> <label class="form-control-label px-3"><?php echo e(GoogleTranslate::trans('Nama Ruangan', app()->getLocale())); ?><span class="text-danger"> *</span></label> <input type="text" id="nama" name="nama" placeholder=""  value="<?php echo e(old('nama', $ruang->nama)); ?>"> </div>
                  <div class="form-group col flex-column d-flex"> <label class="form-control-label px-3"><?php echo e(GoogleTranslate::trans('Lokasi', app()->getLocale())); ?><span class="text-danger"> *</span></label> <input type="text" id="lokasi" name="lokasi" placeholder="" value="<?php echo e(old('lokasi', $ruang->lokasi)); ?>" > </div>
                    <input type="hidden" id="id" name="id" value="<?php echo e(old('id', $ruang->id)); ?>">
                    <div class="form-group col flex-column d-flex"> <label class="form-control-label px-3"><?php echo e(GoogleTranslate::trans('Tingkat Kebisingan', app()->getLocale())); ?><span class="text-danger"> *</span></label> <input type="text" id="bising" name="bising" placeholder="" value="<?php echo e(old('bising', $ruang->bising)); ?>" > </div>
                  <div class="form-group col"> <button type="submit" class="btn-block btn-primary"><?php echo e(GoogleTranslate::trans('Ubah', app()->getLocale())); ?></button> </div>
              </form>
          </div>
          </div>
        </div>
      </div>
      <div
        class="d-flex flex-column flex-md-row text-center text-md-start justify-content-between py-4 px-4 px-xl-5 bg-primary">
        <!-- Copyright -->
        <div class="text-white mb-3 mb-md-0">
          Copyright © 2023. All rights reserved.
        </div>
        <!-- Copyright -->
    
        <!-- Right -->
        <div>
          <a href="#!" class="text-white me-4">Sistem Informasi AudioTest Pro</a>
        </div>
        <!-- Right -->
      </div>
    </section>


<!-- jQuery -->
<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH D:\Kuliah\TA\siaudiotestpro\resources\views/master/editruang.blade.php ENDPATH**/ ?>