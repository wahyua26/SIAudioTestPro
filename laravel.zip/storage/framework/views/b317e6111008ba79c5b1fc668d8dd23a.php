 
<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html>
<head>
    <title>Home</title>
    <?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
      th {
        text-align: center;
      }
    </style>
</head>
<body class="hold-transition sidebar-mini">
            <?php if(Session::has('success')): ?>
              <script type="text/javascript">
                  swal({
                      title:'Success!',
                      text:"<?php echo e(Session::get('success')); ?>",
                      timer:5000,
                      type:'success',
                      icon: 'success'
                  }).then((value) => {
                    //location.reload();
                  }).catch(swal.noop);
              </script>
            <?php endif; ?>
            <?php if(Session::has('error')): ?>
              <script type="text/javascript">
                  swal({
                      title:'Error!',
                      text:"<?php echo e(Session::get('error')); ?>",
                      timer:5000,
                      type:'error',
                      icon: 'error'
                  }).then((value) => {
                    //location.reload();
                  }).catch(swal.noop);
              </script>
            <?php endif; ?>
            <?php if(isset($errors) && $errors->any()): ?>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <script type="text/javascript">
                  swal({
                      title:'Error!',
                      text:"<?php echo e($error); ?>",
                      timer:5000,
                      type:'error',
                      icon: 'error'
                  }).then((value) => {
                    //location.reload();
                  }).catch(swal.noop);
                </script>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
<div class="wrapper ">

  <!-- Navbar -->
  
  <nav class="main-header navbar navbar-expand navbar-white navbar-light bg-primary">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      
    </ul>

    
    
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php echo $__env->make('layouts.side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm">
            <h1 class="m-0 font-weight-bold">DASHBOARD</h1>
          </div><!-- /.col -->
          <div class="col-sm">
            
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <!-- Main content -->
    <div class="content">
      <div class="row">
        <div class="col"></div>
        <div class="col-7">
          <div>
            <canvas id="myChart"></canvas>
            <input type="hidden" id="januari" value="<?php echo e($januari); ?>">
            <input type="hidden" id="februari" value="<?php echo e($februari); ?>">
            <input type="hidden" id="maret" value="<?php echo e($maret); ?>">
            <input type="hidden" id="april" value="<?php echo e($april); ?>">
            <input type="hidden" id="mei" value="<?php echo e($mei); ?>">
            <input type="hidden" id="juni" value="<?php echo e($juni); ?>">
          </div>
        </div>
        <div class="col"></div>
      </div>
      <br>
      <div class="row">
        <div class="col"></div>
        <div class="col-lg-3">
          <div class="small-box text-white">
            <div class="inner">
              <h3><?php echo e($audiometri); ?></h3>
              <p><?php echo e(GoogleTranslate::trans('Hasil Audiometri', app()->getLocale())); ?></p>
            </div>
            <div class="icon">
              <i class="nav-icon fas fa-file-medical"></i>
            </div>
            <a href="/audiometri-pegawai/<?php echo e(auth()->user()->id); ?>" class="small-box-footer text-white"><?php echo e(GoogleTranslate::trans('More Info', app()->getLocale())); ?> <i class="fas fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <div class="col"></div>
      </div>
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Main Footer -->
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
<!-- ./wrapper -->

</div>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
  const januari = document.getElementById('januari').value;
  const februari = document.getElementById('februari').value;
  const maret = document.getElementById('maret').value;
  const april = document.getElementById('april').value;
  const mei = document.getElementById('mei').value;
  const juni = document.getElementById('juni').value;
  
  const ctx = document.getElementById('myChart');

  new Chart(ctx, {
    type: 'line',
    data: {
      labels: ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni'],
      datasets: [{
        label: 'Persentase Tingkat Pendengaran',
        data: [januari, februari, maret, april, mei, juni],
        borderWidth: 1
      }]
    },
    options: {
      scales: {
        y: {
          beginAtZero: true
        }
      }
    }
  });
</script>
<!-- jQuery -->
<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH D:\Kuliah\TA\siaudiotestpro\resources\views/homePegawai.blade.php ENDPATH**/ ?>